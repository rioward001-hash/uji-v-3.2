package com.pras.ujidana;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Catatan hasil uji — disimpan di file supaya tidak hilang saat aplikasi ditutup. */
public class Hasil {

    public interface Pendengar { void berubah(); }

    static Pendengar pendengar;
    private static final Handler UTAMA = new Handler(Looper.getMainLooper());
    private static final long BATAS_BYTE = 400 * 1024;

    private static File file(Context c) { return new File(c.getFilesDir(), "hasil.txt"); }

    public static synchronized void tulis(Context c, String teks) {
        String jam = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        try {
            File f = file(c);
            if (f.length() > BATAS_BYTE) f.delete();
            FileOutputStream o = new FileOutputStream(f, true);
            o.write(("[" + jam + "] " + teks + "\n").getBytes("UTF-8"));
            o.close();
        } catch (Exception ignored) { }
        UTAMA.post(new Runnable() {
            @Override public void run() { if (pendengar != null) pendengar.berubah(); }
        });
    }

    public static synchronized String baca(Context c) {
        try {
            File f = file(c);
            if (!f.exists()) return "";
            byte[] b = new byte[(int) f.length()];
            FileInputStream in = new FileInputStream(f);
            int n = 0;
            while (n < b.length) {
                int r = in.read(b, n, b.length - n);
                if (r < 0) break;
                n += r;
            }
            in.close();
            return new String(b, 0, n, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    public static synchronized void hapus(Context c) {
        file(c).delete();
        if (pendengar != null) pendengar.berubah();
    }
}
