package com.pras.ujidana;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Layanan Aksesibilitas UJI v3. Hanya MEMBACA layar dan mengetuk menu Riwayat / satu transaksi /
 * tombol refresh. Tidak pernah mengetik PIN/password dan tidak menekan tombol bayar / transfer.
 */
public class BacaService extends AccessibilityService {

    static BacaService aktif;

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private TextView tombol;
    private int manualKe = 0;

    private boolean berjalan = false;
    private String paket = "";
    private String nama = "";
    private boolean goPay = false;

    private static final Pattern P_NOMINAL = Pattern.compile("-?\\s?Rp\\s?[\\d.]+");
    private static final Pattern P_JAM = Pattern.compile("\\b\\d{1,2}[:.]\\d{2}\\b");
    private static final Pattern P_TGL = Pattern.compile("\\d{1,2}\\s+\\w+\\s+20\\d{2}");

    // ───────────────────────── siklus layanan ─────────────────────────

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        aktif = this;
        Hasil.tulis(this, "✓ Layanan Aksesibilitas tersambung");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override public boolean onUnbind(Intent intent) { sembunyikanTombol(); aktif = null; return super.onUnbind(intent); }
    @Override public void onDestroy() { sembunyikanTombol(); aktif = null; super.onDestroy(); }

    void tulis(String s) { Hasil.tulis(this, s); }

    // ───────────────────────── uji otomatis ─────────────────────────

    void mulaiUji(String paketApp, String namaApp) {
        if (berjalan) { tulis("⚠ Uji sebelumnya masih berjalan, tunggu sampai selesai"); return; }
        berjalan = true;
        paket = paketApp;
        nama = namaApp;
        goPay = paketApp.contains("gopay");

        String versiUji = "?";
        try { versiUji = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
        tulis("════════ UJI " + nama + " (aplikasi uji v" + versiUji + ") ════════");
        tulis("HP: " + Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE);
        try {
            tulis(nama + " versi " + getPackageManager().getPackageInfo(paket, 0).versionName);
        } catch (Exception e) {
            tulis("✗ " + nama + " tidak terpasang"); selesai(); return;
        }
        if (!bukaApp()) { selesai(); return; }
        tulis("… membuka " + nama);
        tungguTerbuka(0);
    }

    private boolean bukaApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(paket);
        if (i == null) { tulis("✗ " + nama + " tidak bisa dibuka"); return false; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); return true; }
        catch (Exception e) { tulis("✗ Gagal membuka " + nama + ": " + e.getMessage()); return false; }
    }

    private String paketAktif() {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        return (r == null || r.getPackageName() == null) ? "" : r.getPackageName().toString();
    }

    private void tungguTerbuka(final int coba) {
        if (paket.equals(paketAktif())) {
            tulis("✓ " + nama + " terbuka");
            h.postDelayed(new Runnable() { @Override public void run() { bukaMenu(); } }, 3500);
            return;
        }
        if (coba >= 20) { tulis("✗ " + nama + " tidak terbuka dalam 20 detik"); selesai(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tungguTerbuka(coba + 1); } }, 1000);
    }

    private void bukaMenu() {
        AccessibilityNodeInfo menu = cariTeks(goPay
                ? new String[]{"riwayat"}
                : new String[]{"aktivitas", "riwayat", "history"});
        if (menu == null) {
            tulis("✗ Menu riwayat tidak ketemu. Pakai tombol 📸 manual.");
            kembali(); return;
        }
        tulis("→ Buka menu: \"" + teksNode(menu) + "\"");
        klik(menu);
        tungguDaftar(0);
    }

    private void tungguDaftar(final int coba) {
        if (daftarSiap()) {
            tulis("✓ Daftar transaksi muncul (±" + (coba + 1) + " dtk)");
            h.postDelayed(new Runnable() { @Override public void run() { tampilkanDaftar("DAFTAR AWAL"); } }, 800);
            return;
        }
        if (coba >= 15) { tulis("⚠ Daftar belum muncul 15 dtk"); ringkas("DAFTAR (mungkin belum siap)"); mulaiRefresh(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tungguDaftar(coba + 1); } }, 1000);
    }

    private void tampilkanDaftar(String judul) {
        ringkas(judul);
        mulaiRefresh();
    }

    private boolean daftarSiap() {
        for (String t : teksUrut()) {
            String l = t.toLowerCase(Locale.ROOT);
            if (goPay) {
                if (l.startsWith("diterima dari") || l.startsWith("ditransfer ke") || l.equals("riwayat transaksi")) return true;
            } else {
                if (l.startsWith("terima uang") || l.startsWith("kirim ke") || l.equals("bulan ini")) return true;
            }
        }
        return false;
    }

    // ───────────────────────── uji refresh ─────────────────────────

    private void mulaiRefresh() {
        tulis("──── UJI REFRESH ────");
        if (goPay) {
            tulis("GoPay cara: gulir ke bawah");
            refreshGulir();
            h.postDelayed(new Runnable() { @Override public void run() {
                ringkas("Setelah GULIR");
                lanjutKeDetail();
            } }, 2500);
        } else {
            refreshDana1();
        }
    }

    // DANA cara 1: gulir ke bawah
    private void refreshDana1() {
        tulis("DANA cara 1: gulir ke bawah");
        refreshGulir();
        h.postDelayed(new Runnable() { @Override public void run() {
            ringkas("Setelah cara 1 (GULIR)");
            refreshDana2();
        } }, 2500);
    }

    // DANA cara 2: tekan kembali lalu masuk Aktivitas lagi
    private void refreshDana2() {
        tulis("DANA cara 2: kembali lalu masuk Aktivitas lagi");
        performGlobalAction(GLOBAL_ACTION_BACK);
        h.postDelayed(new Runnable() { @Override public void run() {
            AccessibilityNodeInfo menu = cariTeks(new String[]{"aktivitas", "riwayat", "history"});
            if (menu == null) { tulis("  ⚠ tombol Aktivitas tidak ketemu setelah kembali"); refreshDana3(); return; }
            klik(menu);
            h.postDelayed(new Runnable() { @Override public void run() {
                ringkas("Setelah cara 2 (BACK + masuk lagi)");
                refreshDana3();
            } }, 4000);
        } }, 2500);
    }

    // DANA cara 3: force close DANA lalu buka lagi
    private void refreshDana3() {
        tulis("DANA cara 3: force close lalu buka lagi");
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.setData(Uri.parse("package:" + paket));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); } catch (Exception e) { tulis("  ✗ tidak bisa buka Info aplikasi: " + e.getMessage()); lanjutKeDetail(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tekanPaksaBerhenti(0); } }, 2500);
    }

    private void tekanPaksaBerhenti(final int coba) {
        AccessibilityNodeInfo b = cariTeksMengandung(new String[]{"paksa berhenti", "berhenti paksa", "force stop", "paksa henti"});
        if (b != null) {
            tulis("  → tekan \"" + teksNode(b) + "\" (" + klik(b) + ")");
            h.postDelayed(new Runnable() { @Override public void run() { konfirmasiPaksa(0); } }, 1500);
            return;
        }
        if (coba >= 6) { tulis("  ⚠ tombol Paksa Berhenti tidak ketemu — lewati, buka DANA lagi"); bukaUlangDana(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tekanPaksaBerhenti(coba + 1); } }, 1000);
    }

    private void konfirmasiPaksa(final int coba) {
        // Dialog konfirmasi: tombol "OK" / "Oke" / "Paksa Berhenti"
        for (AccessibilityNodeInfo n : semuaNode()) {
            String t = teksNode(n).toLowerCase(Locale.ROOT);
            if (t.equals("ok") || t.equals("oke") || t.equals("paksa berhenti") || t.equals("force stop")) {
                tulis("  → konfirmasi \"" + teksNode(n) + "\" (" + klik(n) + ")");
                h.postDelayed(new Runnable() { @Override public void run() { bukaUlangDana(); } }, 1500);
                return;
            }
        }
        if (coba >= 4) { tulis("  (tidak ada dialog konfirmasi / sudah berhenti)"); bukaUlangDana(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { konfirmasiPaksa(coba + 1); } }, 800);
    }

    private void bukaUlangDana() {
        performGlobalAction(GLOBAL_ACTION_HOME);
        h.postDelayed(new Runnable() { @Override public void run() {
            bukaApp();
            h.postDelayed(new Runnable() { @Override public void run() { tungguTerbukaLagi(0); } }, 3500);
        } }, 1500);
    }

    private void tungguTerbukaLagi(final int coba) {
        if (paket.equals(paketAktif())) {
            AccessibilityNodeInfo menu = cariTeks(new String[]{"aktivitas", "riwayat", "history"});
            if (menu != null) klik(menu);
            h.postDelayed(new Runnable() { @Override public void run() {
                ringkas("Setelah cara 3 (FORCE CLOSE + buka lagi)");
                lanjutKeDetail();
            } }, 4500);
            return;
        }
        if (coba >= 15) { tulis("  ⚠ DANA tidak terbuka lagi dalam 15 dtk"); lanjutKeDetail(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tungguTerbukaLagi(coba + 1); } }, 1000);
    }

    // ───────────────────────── uji baca detail ─────────────────────────

    private void lanjutKeDetail() {
        tulis("──── UJI BACA DETAIL (1 transaksi) ────");
        AccessibilityNodeInfo baris = cariBarisMasuk();
        if (baris == null) {
            tulis("✗ Tidak ketemu baris transaksi MASUK yang terlihat. Pakai 📸 manual untuk cek detail.");
            kembali(); return;
        }
        tulis("→ Ketuk transaksi: \"" + teksNode(baris) + "\" (" + klik(baris) + ")");
        h.postDelayed(new Runnable() { @Override public void run() { tungguDetail(0); } }, 2000);
    }

    /** Tunggu halaman detail benar-benar terbuka (kadang ada popup/event yang lambat). */
    private void tungguDetail(final int coba) {
        if (detailSiap()) {
            tulis("✓ Halaman detail terbuka (±" + (coba + 2) + " dtk)");
            ringkasDetail("DETAIL (sebelum digulir)");   // nama DANA ada di atas
            geser(true);                                  // jam GoPay ada di bawah
            h.postDelayed(new Runnable() { @Override public void run() {
                ringkasDetail("DETAIL (setelah digulir)");
                tulis("→ kembali");
                performGlobalAction(GLOBAL_ACTION_BACK);
                h.postDelayed(new Runnable() { @Override public void run() { kembali(); } }, 1500);
            } }, 2000);
            return;
        }
        if (coba >= 12) {
            tulis("⚠ Detail tidak terbuka dalam 14 dtk — mungkin ada popup/event yang menutupi");
            ringkasDetail("LAYAR SAAT GAGAL");
            performGlobalAction(GLOBAL_ACTION_BACK);
            h.postDelayed(new Runnable() { @Override public void run() { kembali(); } }, 1500);
            return;
        }
        h.postDelayed(new Runnable() { @Override public void run() { tungguDetail(coba + 1); } }, 1000);
    }

    /** Ciri halaman detail transaksi (bukan daftar lagi). */
    private boolean detailSiap() {
        for (String t : teksUrut()) {
            String l = t.toLowerCase(Locale.ROOT);
            if (l.contains("rincian transaksi") || l.contains("id transaksi") || l.contains("id dana")
                    || l.contains("detail transaksi") || l.startsWith("terima transfer")) return true;
        }
        return false;
    }

    private void kembali() {
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(i);
        } catch (Exception ignored) { }
        selesai();
    }

    private void selesai() { berjalan = false; tulis("════════ SELESAI ════════"); }

    // ───────────────────────── RINGKAS (hasil rapi) ─────────────────────────

    /** Daftar transaksi, versi rapi: nama · nominal · jam (satu baris per transaksi). */
    private void ringkas(String judul) {
        List<String> baris = teksUrut();
        List<String> out = goPay ? ringkasGoPay(baris) : ringkasDana(baris);
        StringBuilder sb = new StringBuilder("📋 " + judul + "\n");
        if (out.isEmpty()) {
            sb.append("  (tidak ada transaksi terbaca)\n");
            int c = 0;
            for (String t : baris) if (P_NOMINAL.matcher(t).find() && c++ < 12) sb.append("  · ").append(ringkasTeks(t)).append("\n");
        } else {
            int no = 1;
            for (String s : out) { sb.append("  ").append(no++).append(". ").append(s).append("\n"); if (no > 15) break; }
            sb.append("  (").append(out.size()).append(" transaksi)");
        }
        tulis(sb.toString());
    }

    private void ringkasDetail(String judul) {
        List<String> baris = teksUrut();
        String nmn = "", jam = "", tgl = "", nm = "";
        for (String t : baris) {
            String low = t.toLowerCase(Locale.ROOT);
            int d = low.indexOf(" dari ");
            if (d >= 0 && low.contains("terima")) {
                nm = t.substring(d + 6).trim();
                Matcher m = P_NOMINAL.matcher(t); if (m.find()) nmn = rapiRp(m.group());
            }
            if (low.startsWith("diterima dari")) nm = t.substring(13).trim();
            if (nmn.isEmpty()) { Matcher m = P_NOMINAL.matcher(t); if (m.find() && t.length() < 40) nmn = rapiRp(m.group()); }
            if (jam.isEmpty()) { Matcher m = P_JAM.matcher(t); if (m.find() && t.length() < 40) jam = m.group().replace('.', ':'); }
            if (tgl.isEmpty()) { Matcher m = P_TGL.matcher(t); if (m.find()) tgl = m.group(); }
        }
        StringBuilder sb = new StringBuilder("🔎 " + judul + "\n");
        sb.append("  Nama   : ").append(nm.isEmpty() ? "— (tidak terbaca)" : nm).append("\n");
        sb.append("  Nominal: ").append(nmn.isEmpty() ? "—" : nmn).append("\n");
        sb.append("  Tanggal: ").append(tgl.isEmpty() ? "—" : tgl).append("\n");
        sb.append("  Jam    : ").append(jam.isEmpty() ? "— (tidak terbaca)" : jam);
        tulis(sb.toString());
    }

    private List<String> ringkasGoPay(List<String> baris) {
        List<String> out = new ArrayList<>();
        for (String t : baris) {
            String low = t.toLowerCase(Locale.ROOT);
            if (!low.startsWith("diterima dari")) continue; // hanya uang MASUK
            Matcher m = P_NOMINAL.matcher(t);
            String rp = m.find() ? rapiRp(m.group()) : "—";
            String nm = t.substring(13).trim();
            int rpos = nm.indexOf("Rp");
            if (rpos > 0) nm = nm.substring(0, rpos).trim();
            out.add(nm + " · " + rp);
        }
        return out;
    }

    private List<String> ringkasDana(List<String> baris) {
        List<String> out = new ArrayList<>();
        String nm = null, jam = null, rp = null;
        for (String t : baris) {
            String low = t.toLowerCase(Locale.ROOT);
            boolean anchor = low.startsWith("terima uang") || low.startsWith("kirim ke") || low.startsWith("terima transfer");
            if (anchor) {
                if (nm != null) out.add(gabung(nm, rp, jam));
                nm = low.startsWith("terima uang") ? "Terima Uang" : t;
                jam = null; rp = null;
                Matcher m = P_NOMINAL.matcher(t); if (m.find()) rp = rapiRp(m.group());
                int d = low.indexOf(" dari ");
                if (d >= 0) nm = "dari " + t.substring(d + 6).trim();
                continue;
            }
            if (nm == null) continue;
            Matcher mj = P_JAM.matcher(t); if (jam == null && mj.find() && t.length() < 40) jam = mj.group().replace('.', ':');
            Matcher mr = P_NOMINAL.matcher(t); if (rp == null && mr.find() && t.length() < 25) rp = rapiRp(mr.group());
        }
        if (nm != null) out.add(gabung(nm, rp, jam));
        return out;
    }

    private String gabung(String nm, String rp, String jam) {
        String s = nm + " · " + (rp == null ? "—" : rp);
        if (jam != null) s += " · " + jam;
        return s;
    }

    private String rapiRp(String s) { return s.replace(" ", ""); }
    private String ringkasTeks(String s) { return s.length() > 70 ? s.substring(0, 70) + "…" : s; }

    // ───────────────────────── membaca & mencari ─────────────────────────

    /** Semua teks yang terlihat di jendela aplikasi target, urut dari atas ke bawah. */
    private List<String> teksUrut() {
        final List<Long> yPos = new ArrayList<>();
        final List<String> teks = new ArrayList<>();
        List<AccessibilityWindowInfo> jendela = null;
        try { jendela = getWindows(); } catch (Exception ignored) { }
        boolean ada = false;
        if (jendela != null) {
            for (AccessibilityWindowInfo w : jendela) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue;
                AccessibilityNodeInfo root = w.getRoot();
                if (root == null) continue;
                String pk = root.getPackageName() == null ? "" : root.getPackageName().toString();
                if (pk.equals(getPackageName()) || pk.equals("com.android.systemui")) continue;
                ada = true;
                kumpulTeks(root, 0, teks, yPos);
            }
        }
        if (!ada) {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) kumpulTeks(root, 0, teks, yPos);
        }
        Integer[] urut = new Integer[teks.size()];
        for (int i = 0; i < urut.length; i++) urut[i] = i;
        java.util.Arrays.sort(urut, new java.util.Comparator<Integer>() {
            @Override public int compare(Integer a, Integer b) { return Long.compare(yPos.get(a), yPos.get(b)); }
        });
        List<String> hasil = new ArrayList<>();
        String sebelum = null;
        for (int i : urut) {
            String t = teks.get(i);
            if (t.equals(sebelum)) continue;
            hasil.add(t);
            sebelum = t;
        }
        return hasil;
    }

    private void kumpulTeks(AccessibilityNodeInfo n, int dk, List<String> teks, List<Long> yPos) {
        if (n == null || dk > 60) return;
        String t = teksNode(n);
        if (t.length() > 0) {
            Rect b = new Rect(); n.getBoundsInScreen(b);
            teks.add(t);
            yPos.add((long) b.top * 10000 + b.left);
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = null; try { c = n.getChild(i); } catch (Exception ignored) { }
            kumpulTeks(c, dk + 1, teks, yPos);
        }
    }

    private void kumpulkan(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int dk) {
        if (n == null || dk > 60) return;
        out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = null; try { c = n.getChild(i); } catch (Exception ignored) { }
            kumpulkan(c, out, dk + 1);
        }
    }

    private List<AccessibilityNodeInfo> semuaNode() {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        kumpulkan(getRootInActiveWindow(), out, 0);
        return out;
    }

    private static String teksNode(AccessibilityNodeInfo n) {
        String t = n.getText() == null ? "" : n.getText().toString().trim();
        if (t.length() == 0 && n.getContentDescription() != null) t = n.getContentDescription().toString().trim();
        return t.replace('\n', ' ');
    }

    private AccessibilityNodeInfo cariTeks(String[] kata) {
        List<AccessibilityNodeInfo> semua = semuaNode();
        for (String k : kata)
            for (AccessibilityNodeInfo n : semua)
                if (teksNode(n).toLowerCase(Locale.ROOT).equals(k)) return n;
        for (String k : kata)
            for (AccessibilityNodeInfo n : semua) {
                String t = teksNode(n).toLowerCase(Locale.ROOT);
                if (t.length() > 0 && t.length() < 30 && t.contains(k)) return n;
            }
        return null;
    }

    private AccessibilityNodeInfo cariTeksMengandung(String[] kata) {
        for (AccessibilityNodeInfo n : semuaNode()) {
            String t = teksNode(n).toLowerCase(Locale.ROOT);
            for (String k : kata) if (t.contains(k)) return n;
        }
        return null;
    }

    /** Baris transaksi MASUK teratas yang terlihat: GoPay "Diterima dari…", DANA "Terima Uang". */
    private AccessibilityNodeInfo cariBarisMasuk() {
        int tinggi = getResources().getDisplayMetrics().heightPixels;
        AccessibilityNodeInfo terbaik = null; int yBaik = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo n : semuaNode()) {
            String low = teksNode(n).toLowerCase(Locale.ROOT);
            boolean cocok = goPay ? low.startsWith("diterima dari") : low.startsWith("terima uang");
            if (!cocok) continue;
            Rect b = new Rect(); n.getBoundsInScreen(b);
            if (b.height() <= 0 || b.centerY() < tinggi * 0.15 || b.centerY() > tinggi * 0.85) continue;
            if (b.centerY() < yBaik) { yBaik = b.centerY(); terbaik = n; }
        }
        return terbaik;
    }

    private String klik(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo x = n; int naik = 0;
        while (x != null && !x.isClickable() && naik < 8) { x = x.getParent(); naik++; }
        if (x != null && x.isClickable() && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "klik";
        Rect b = new Rect(); n.getBoundsInScreen(b);
        ketuk(b.centerX(), b.centerY());
        return "ketuk " + b.centerX() + "," + b.centerY();
    }

    private void ketuk(int x, int y) {
        Path p = new Path(); p.moveTo(x, y);
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 80)).build(), null, null);
    }

    /** Gulir daftar. maju = turun. */
    private String geser(boolean maju) {
        AccessibilityNodeInfo besar = null; int luas = 0;
        for (AccessibilityNodeInfo n : semuaNode()) {
            if (!n.isScrollable()) continue;
            Rect b = new Rect(); n.getBoundsInScreen(b);
            int l = b.width() * b.height();
            if (l > luas) { luas = l; besar = n; }
        }
        if (besar != null && besar.performAction(maju
                ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))
            return "gulir";
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int x = dm.widthPixels / 2, atas = (int) (dm.heightPixels * 0.30f), bawah = (int) (dm.heightPixels * 0.75f);
        Path p = new Path();
        if (maju) { p.moveTo(x, bawah); p.lineTo(x, atas); } else { p.moveTo(x, atas); p.lineTo(x, bawah); }
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 450)).build(), null, null);
        return "usap";
    }

    /** Tarik ke bawah dari atas layar (pull-to-refresh). */
    private void refreshGulir() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int x = dm.widthPixels / 2, atas = (int) (dm.heightPixels * 0.30f), bawah = (int) (dm.heightPixels * 0.80f);
        Path p = new Path(); p.moveTo(x, atas); p.lineTo(x, bawah);
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 500)).build(), null, null);
    }

    // ───────────────────────── tombol 📸 manual ─────────────────────────

    boolean tombolTampil() { return tombol != null; }

    void tampilkanTombol() {
        if (tombol != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        final float dp = getResources().getDisplayMetrics().density;
        int ukuran = (int) (58 * dp);
        tombol = new TextView(this);
        tombol.setText("📸"); tombol.setTextSize(26); tombol.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL); bg.setColor(0xFFF0B90B); bg.setStroke((int) (2 * dp), 0xFF000000);
        tombol.setBackground(bg);
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(ukuran, ukuran,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.END | Gravity.CENTER_VERTICAL; lp.x = (int) (12 * dp);
        tombol.setOnTouchListener(new View.OnTouchListener() {
            float awalY; int awalLpY; boolean jauh;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: awalY = e.getRawY(); awalLpY = lp.y; jauh = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float dy = e.getRawY() - awalY;
                        if (Math.abs(dy) > 12 * dp) jauh = true;
                        if (jauh) { lp.y = awalLpY + (int) dy; try { wm.updateViewLayout(tombol, lp); } catch (Exception ignored) { } }
                        return true;
                    case MotionEvent.ACTION_UP: if (!jauh) bacaManual(); return true;
                }
                return false;
            }
        });
        try { wm.addView(tombol, lp); tulis("📸 Tombol baca manual tampil (geser untuk memindah)"); }
        catch (Exception e) { tombol = null; tulis("✗ Tombol melayang gagal: " + e.getMessage()); }
    }

    void sembunyikanTombol() {
        if (tombol != null && wm != null) { try { wm.removeView(tombol); } catch (Exception ignored) { } }
        tombol = null;
    }

    private void bacaManual() {
        manualKe++;
        String pk = paketAktif();
        goPay = pk.contains("gopay");
        List<String> baris = teksUrut();
        boolean detail = false;
        for (String t : baris) { String l = t.toLowerCase(Locale.ROOT);
            if (l.contains("rincian transaksi") || l.startsWith("terima transfer") || l.startsWith("detail transaksi")) { detail = true; break; } }
        if (detail) ringkasDetail("DETAIL (manual)"); else ringkas("📸 MANUAL #" + manualKe + " (" + pk + ")");
        Toast.makeText(this, "📸 #" + manualKe, Toast.LENGTH_SHORT).show();
    }
}
