package com.pras.ujidana;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements Hasil.Pendengar {

    private static final int HITAM = 0xFF0B0E11;
    private static final int KARTU = 0xFF1E2329;
    private static final int KUNING = 0xFFF0B90B;
    private static final int PUTIH = 0xFFEAECEF;
    private static final int ABU = 0xFF848E9C;
    private static final int HIJAU = 0xFF0ECB81;
    private static final int MERAH = 0xFFF6465D;

    private float dp;
    private ScrollView gulir;
    private TextView status, hasil;
    private Button tombolManual;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dp = getResources().getDisplayMetrics().density;

        gulir = new ScrollView(this);
        gulir.setBackgroundColor(HITAM);
        LinearLayout isi = new LinearLayout(this);
        isi.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * dp);
        isi.setPadding(pad, pad, pad, pad);
        gulir.addView(isi);

        TextView judul = teks("🧪 Uji Baca DANA", 22, KUNING);
        judul.setTypeface(Typeface.DEFAULT_BOLD);
        isi.addView(judul);
        isi.addView(teks("Aplikasi uji: mengecek apakah riwayat DANA / GoPay bisa dibaca lewat Aksesibilitas. "
                + "Hanya membaca layar, tidak pernah transfer atau mengetik apa pun.", 13, ABU));

        status = teks("", 15, PUTIH);
        status.setPadding(pad, pad, pad, pad);
        status.setBackground(kotak(KARTU));
        LinearLayout.LayoutParams lpStatus = new LinearLayout.LayoutParams(-1, -2);
        lpStatus.topMargin = (int) (12 * dp);
        isi.addView(status, lpStatus);

        isi.addView(subjudul("Langkah 1 — izin"));
        isi.addView(tombol("⚙ Buka pengaturan Aksesibilitas", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));
        isi.addView(teks("Cari \"Uji Baca DANA\" lalu nyalakan. Kalau saklarnya abu-abu / tidak bisa dinyalakan "
                + "(Android 13 ke atas): tekan tombol di bawah → ⋮ (pojok kanan atas) → \"Izinkan setelan terbatas\", "
                + "lalu ulangi.", 12, ABU));
        isi.addView(tombol("ℹ Buka Info aplikasi", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        }));

        isi.addView(subjudul("Langkah 2 — uji otomatis"));
        isi.addView(tombol("🧪 Uji otomatis DANA", true, new View.OnClickListener() {
            @Override public void onClick(View v) { uji("id.dana", "DANA"); }
        }));
        isi.addView(tombol("🧪 Uji otomatis GoPay", false, new View.OnClickListener() {
            @Override public void onClick(View v) { uji("com.gojek.gopay", "GoPay"); }
        }));
        isi.addView(teks("Aplikasi akan membuka DANA → Riwayat → menggulir → mengetuk 1 transaksi → kembali ke sini. "
                + "Jangan sentuh HP selama ±30 detik.", 12, ABU));

        isi.addView(subjudul("Cadangan — baca manual"));
        tombolManual = tombol("", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                BacaService s = BacaService.aktif;
                if (s == null) { belumIzin(); return; }
                if (s.tombolTampil()) s.sembunyikanTombol(); else s.tampilkanTombol();
                perbarui();
            }
        });
        isi.addView(tombolManual);
        isi.addView(teks("Muncul bola kuning 📸 di pinggir layar. Buka DANA sendiri, buka Riwayat / detail transaksi, "
                + "lalu tekan 📸 di tiap layar. Teks layar itu langsung tercatat di hasil.", 12, ABU));

        isi.addView(subjudul("Hasil"));
        LinearLayout baris = new LinearLayout(this);
        baris.setOrientation(LinearLayout.HORIZONTAL);
        baris.addView(tombolKecil("📤 Bagikan", new View.OnClickListener() {
            @Override public void onClick(View v) { bagikan(); }
        }));
        baris.addView(tombolKecil("📋 Salin", new View.OnClickListener() {
            @Override public void onClick(View v) { salin(); }
        }));
        baris.addView(tombolKecil("🗑 Hapus", new View.OnClickListener() {
            @Override public void onClick(View v) { Hasil.hapus(MainActivity.this); }
        }));
        isi.addView(baris);

        hasil = teks("", 11, PUTIH);
        hasil.setTypeface(Typeface.MONOSPACE);
        hasil.setTextIsSelectable(true);
        hasil.setPadding(pad, pad, pad, pad);
        hasil.setBackground(kotak(KARTU));
        LinearLayout.LayoutParams lpHasil = new LinearLayout.LayoutParams(-1, -2);
        lpHasil.topMargin = (int) (8 * dp);
        isi.addView(hasil, lpHasil);

        setContentView(gulir);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Hasil.pendengar = this;
        perbarui();
        berubah();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (Hasil.pendengar == this) Hasil.pendengar = null;
    }

    @Override
    public void berubah() {
        perbarui();
        String s = Hasil.baca(this);
        hasil.setText(s.length() == 0 ? "(belum ada hasil)" : s);
        gulir.post(new Runnable() {
            @Override public void run() { gulir.fullScroll(View.FOCUS_DOWN); }
        });
    }

    private boolean izinNyala() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(getPackageName() + "/");
    }

    private void perbarui() {
        BacaService s = BacaService.aktif;
        if (s != null) {
            status.setText("✅ Aksesibilitas NYALA — siap diuji");
            status.setTextColor(HIJAU);
        } else if (izinNyala()) {
            status.setText("🟡 Aksesibilitas dinyalakan tapi layanan belum tersambung. Matikan lalu nyalakan lagi.");
            status.setTextColor(KUNING);
        } else {
            status.setText("❌ Aksesibilitas MATI — lakukan Langkah 1 dulu");
            status.setTextColor(MERAH);
        }
        tombolManual.setText(s != null && s.tombolTampil() ? "📸 Sembunyikan tombol baca manual" : "📸 Tampilkan tombol baca manual");
    }

    private void uji(String paket, String nama) {
        BacaService s = BacaService.aktif;
        if (s == null) { belumIzin(); return; }
        s.mulaiUji(paket, nama);
    }

    private void belumIzin() {
        Toast.makeText(this, "Nyalakan Aksesibilitas dulu (Langkah 1)", Toast.LENGTH_LONG).show();
    }

    private void bagikan() {
        String s = Hasil.baca(this);
        if (s.length() == 0) { Toast.makeText(this, "Belum ada hasil", Toast.LENGTH_SHORT).show(); return; }
        if (s.length() > 60000) s = "…(bagian awal dipotong)\n" + s.substring(s.length() - 60000);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "Hasil Uji Baca DANA");
        i.putExtra(Intent.EXTRA_TEXT, s);
        startActivity(Intent.createChooser(i, "Bagikan hasil uji"));
    }

    private void salin() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("hasil uji", Hasil.baca(this)));
        Toast.makeText(this, "Hasil disalin", Toast.LENGTH_SHORT).show();
    }

    // ───────────── bantuan tampilan ─────────────

    private TextView teks(String s, int ukuran, int warna) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(ukuran);
        t.setTextColor(warna);
        t.setPadding(0, (int) (4 * dp), 0, (int) (4 * dp));
        return t;
    }

    private TextView subjudul(String s) {
        TextView t = teks(s, 15, PUTIH);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, (int) (18 * dp), 0, (int) (6 * dp));
        return t;
    }

    private GradientDrawable kotak(int warna) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(warna);
        g.setCornerRadius(12 * dp);
        return g;
    }

    private Button tombol(String s, boolean utama, View.OnClickListener aksi) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(utama ? 0xFF000000 : PUTIH);
        b.setBackground(kotak(utama ? KUNING : KARTU));
        b.setOnClickListener(aksi);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, (int) (50 * dp));
        lp.topMargin = (int) (6 * dp);
        b.setLayoutParams(lp);
        return b;
    }

    private Button tombolKecil(String s, View.OnClickListener aksi) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTextColor(PUTIH);
        b.setBackground(kotak(KARTU));
        b.setOnClickListener(aksi);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (44 * dp), 1f);
        lp.rightMargin = (int) (6 * dp);
        b.setLayoutParams(lp);
        return b;
    }
}
